import 'package:flutter/material.dart';

void main() => runApp(const ChintakaiiEnglishCall());

class ChintakaiiEnglishCall extends StatelessWidget {
  const ChintakaiiEnglishCall({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Chintakaii English Call',
      theme: ThemeData.dark(useMaterial3: true),
      home: const LiveCallScreen(),
    );
  }
}

class LiveCallScreen extends StatefulWidget {
  const LiveCallScreen({super.key});

  @override
  State<LiveCallScreen> createState() => _LiveCallScreenState();
}

class _LiveCallScreenState extends State<LiveCallScreen> {
  bool recording = true;
  bool muted = false;
  String status = 'Listening...';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF071426),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Text(
                'Chintakaii English Call',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF102B4A),
                  border: Border.all(
                    color: const Color(0xFFF4C95D),
                    width: 3,
                  ),
                ),
                child: const Icon(
                  Icons.record_voice_over_rounded,
                  size: 70,
                  color: Color(0xFFF4C95D),
                ),
              ),
              const SizedBox(height: 15),
              const Text(
                'Your English Partner',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(status, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 20),
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D2036),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Conversation',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 16),
                      Bubble(
                        text: 'Hi Ra! How are you today?',
                        ai: true,
                      ),
                      SizedBox(height: 10),
                      Bubble(
                        text: 'I am good. Today I learning English.',
                        ai: false,
                      ),
                      SizedBox(height: 10),
                      Bubble(
                        text:
                            'Say: “Today I am learning English.”',
                        ai: true,
                      ),
                      Spacer(),
                      Text(
                        'Your corrections will appear here.',
                        style: TextStyle(color: Colors.white54),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ControlButton(
                    icon: muted ? Icons.mic_off : Icons.mic,
                    label: muted ? 'Unmute' : 'Mute',
                    onTap: () => setState(() {
                      muted = !muted;
                      status = muted ? 'Muted' : 'Listening...';
                    }),
                  ),
                  ControlButton(
                    icon: recording
                        ? Icons.stop_circle_outlined
                        : Icons.fiber_manual_record,
                    label: recording ? 'Recording' : 'Record',
                    active: recording,
                    onTap: () => setState(() => recording = !recording),
                  ),
                  ControlButton(
                    icon: Icons.call_end,
                    label: 'End Call',
                    danger: true,
                    onTap: () => setState(() => status = 'Call ended'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                '🔴 Recording • Save it later in Conversation History',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Bubble extends StatelessWidget {
  final String text;
  final bool ai;

  const Bubble({super.key, required this.text, required this.ai});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: ai ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 310),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: ai ? const Color(0xFF17395E) : const Color(0xFF294B35),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(text, style: const TextStyle(fontSize: 15)),
      ),
    );
  }
}

class ControlButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final bool danger;

  const ControlButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(50),
          child: Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: danger
                  ? Colors.redAccent
                  : active
                      ? const Color(0xFFF4C95D)
                      : const Color(0xFF17304C),
            ),
            child: Icon(
              icon,
              color: active ? Colors.black : Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
